# golf
Jeu de golf
Projet, Programmation en JAVA
Algorithmique et Structures de Données 3


Par Benoît Le Badezet
et Glenn Plouhinec


compilation, exécution:
javac java/*.java -d class/ && java -cp class Programme DescriptionFIgureGolf2.txt

