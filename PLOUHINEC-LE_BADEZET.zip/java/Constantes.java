public class Constantes {
	public static final int nbCases = 10;
	public static final int nbPixels = 60;

	public static final int T = 7;
	public static final int profondeurMax = 7;
}
